// EAGLE ESPORTS Firebase app. Fill firebaseConfig before running.
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-app.js";
import { getAuth, GoogleAuthProvider, signInWithPopup, RecaptchaVerifier, signInWithPhoneNumber, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-auth.js";
import { getFirestore, collection, addDoc, getDocs, query, where, orderBy, serverTimestamp, doc, getDoc, runTransaction, limit } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};
// Replace with your own Firebase Authentication UID after first signing in.
// This UID must match the adminUid constant in firestore.rules.
const ADMIN_UID = "PASTE_YOUR_ADMIN_AUTH_UID_HERE";

const statusEl = document.getElementById("status");
let auth, db, currentUser = null, confirmation = null, recaptcha = null;
const $ = id => document.getElementById(id);
const setStatus = msg => statusEl.textContent = msg;
const configured = !Object.values(firebaseConfig).some(v => String(v).startsWith("YOUR_")) && !ADMIN_UID.startsWith("PASTE_");

if (!configured) {
  setStatus("Firebase setup বাকি: public/app.js-এ Firebase config ও Admin UID বসাও। বিস্তারিত README.md-তে আছে।");
} else {
  const app = initializeApp(firebaseConfig);
  auth = getAuth(app); db = getFirestore(app);
  $("googleLogin").onclick = async () => { try { await signInWithPopup(auth, new GoogleAuthProvider()); } catch(e) { setStatus("Google login হয়নি: " + e.message); } };
  $("phoneLogin").onclick = () => { $("phoneModal").classList.add("open"); };
  $("closePhone").onclick = () => $("phoneModal").classList.remove("open");
  $("phoneForm").onsubmit = async e => {
    e.preventDefault();
    try {
      if (!recaptcha) recaptcha = new RecaptchaVerifier(auth, "recaptcha-container", {size:"normal"});
      confirmation = await signInWithPhoneNumber(auth, $("phoneNumber").value.trim(), recaptcha);
      $("otpLabel").classList.remove("hidden"); $("verifyOtp").classList.remove("hidden");
      setStatus("OTP পাঠানো হয়েছে।");
    } catch(err) { setStatus("OTP পাঠানো যায়নি: " + err.message); if(recaptcha){await recaptcha.clear();recaptcha=null;} }
  };
  $("verifyOtp").onclick = async () => { try { await confirmation.confirm($("otpCode").value.trim()); $("phoneModal").classList.remove("open"); } catch(e){setStatus("OTP সঠিক নয় বা মেয়াদ শেষ: "+e.message);} };
  $("logout").onclick = () => signOut(auth);
  $("refresh").onclick = loadTournaments;
  onAuthStateChanged(auth, async user => {
    currentUser = user;
    $("googleLogin").classList.toggle("hidden",!!user);
    $("phoneLogin").classList.toggle("hidden",!!user);
    $("logout").classList.toggle("hidden",!user);
    $("userInfo").textContent = user ? `Signed in: ${user.displayName || user.phoneNumber || user.email || user.uid}` : "লগইন করলে তোমার প্রোফাইল এখানে দেখা যাবে।";
    $("adminSection").classList.toggle("hidden",!user || user.uid !== ADMIN_UID);
    if(user){await ensureProfile(user); await loadMyEntries();} else {$("myEntries").textContent="লগইন করলে তোমার রেজিস্ট্রেশন দেখা যাবে।";}
    await loadTournaments();
    if(user && user.uid===ADMIN_UID) await loadAdminTournaments();
  });
  $("tournamentForm").onsubmit = async e => {
    e.preventDefault();
    if(!isAdmin()) return setStatus("Admin access নেই।");
    try {
      const start = new Date($("tDate").value), deadline = new Date($("tDeadline").value);
      if(deadline > start) return setStatus("Registration deadline ম্যাচের সময়ের আগে হতে হবে।");
      await addDoc(collection(db,"tournaments"), {
        name:$("tName").value.trim(), mode:$("tMode").value, map:$("tMap").value.trim(),
        startAt:start, deadlineAt:deadline, maxPlayers:Number($("tMax").value),
        rules:$("tRules").value.trim(), status:"open", createdAt:serverTimestamp(), createdBy:currentUser.uid
      });
      $("tournamentForm").reset(); setStatus("Tournament প্রকাশিত হয়েছে।");
      await loadTournaments(); await loadAdminTournaments();
    } catch(err){setStatus("Publish হয়নি: "+err.message);}
  };
}

function isAdmin(){return !!currentUser && currentUser.uid===ADMIN_UID;}
async function ensureProfile(user){
  const ref=doc(db,"users",user.uid), snap=await getDoc(ref);
  if(!snap.exists()) await runTransaction(db,async tx=>{const s=await tx.get(ref);if(!s.exists())tx.set(ref,{displayName:user.displayName||"",phoneNumber:user.phoneNumber||"",email:user.email||"",createdAt:serverTimestamp()});});
}
function dateText(d){const date=d?.toDate?d.toDate():d instanceof Date?d:null;return date?date.toLocaleString():"সময় নির্ধারিত নয়";}
async function loadTournaments(){
  try{
    const q=query(collection(db,"tournaments"),orderBy("startAt","asc"),limit(60));
    const snap=await getDocs(q); const host=$("tournaments");host.replaceChildren();
    if(snap.empty){host.innerHTML='<p class="muted">এখনও কোনো টুর্নামেন্ট প্রকাশিত হয়নি।</p>';return;}
    for(const ds of snap.docs){const t=ds.data(),card=document.createElement("article");card.className="t-card";
      const title=document.createElement("h3");title.textContent=t.name;
      const pill=document.createElement("span");pill.className="pill";pill.textContent=t.status==="open"?"REGISTRATION OPEN":"CLOSED";
      const meta=document.createElement("p");meta.className="meta";meta.textContent=`Mode: ${t.mode} · Map: ${t.map||"TBA"}\nStart: ${dateText(t.startAt)}\nLast join: ${dateText(t.deadlineAt)}\nMax players: ${t.maxPlayers}`;
      const rules=document.createElement("p");rules.className="muted";rules.textContent=t.rules||"Tournament rules আয়োজক পরে জানাবেন।";
      const btn=document.createElement("button");btn.className="btn";btn.textContent="Join Tournament";btn.disabled=!currentUser||t.status!=="open";btn.onclick=()=>joinTournament(ds.id,t);
      card.append(pill,title,meta,rules,btn);host.append(card);
    }
  }catch(e){setStatus("Tournament load error: "+e.message+" — Firestore index লাগতে পারে; README দেখো।");}
}
async function joinTournament(tournamentId,t){
  if(!currentUser){setStatus("Join করতে আগে Mobile বা Google দিয়ে Login করো।");return;}
  const now=new Date(), start=t.startAt?.toDate?.(), deadline=t.deadlineAt?.toDate?.();
  if(t.status!=="open" || (deadline && now>deadline) || (start && now>=start)){setStatus("এই টুর্নামেন্টের registration বন্ধ।");return;}
  const regRef=doc(db,"tournaments",tournamentId,"registrations",currentUser.uid);
  try{
    await runTransaction(db,async tx=>{
      const existing=await tx.get(regRef); if(existing.exists()) throw new Error("তুমি ইতিমধ্যে Join করেছ।");
      const tournamentRef=doc(db,"tournaments",tournamentId), latest=await tx.get(tournamentRef);
      if(!latest.exists()||latest.data().status!=="open") throw new Error("Registration বন্ধ।");
      tx.set(regRef,{uid:currentUser.uid,displayName:currentUser.displayName||"",phoneNumber:currentUser.phoneNumber||"",email:currentUser.email||"",joinedAt:serverTimestamp(),status:"registered"});
    });
    setStatus("সফলভাবে Join হয়েছে! My Tournaments-এ দেখো।"); await loadMyEntries(); if(isAdmin())await loadAdminTournaments();
  }catch(e){setStatus(e.message);}
}
async function loadMyEntries(){
  const host=$("myEntries");host.replaceChildren();if(!currentUser)return;
  try{
    const snap=await getDocs(collection(db,"users",currentUser.uid,"entries"));
    if(snap.empty){host.textContent="এখনও কোনো টুর্নামেন্টে Join করোনি।";return;}
    for(const s of snap.docs){const p=document.createElement("p");p.className="entry";p.textContent=s.data().tournamentName||s.id;host.append(p);}
  }catch(e){host.textContent="Entries load হয়নি: "+e.message;}
}
async function loadAdminTournaments(){
  if(!isAdmin())return;
  const host=$("adminTournaments");host.replaceChildren();
  const snap=await getDocs(query(collection(db,"tournaments"),orderBy("startAt","desc"),limit(50)));
  for(const s of snap.docs){
    const t=s.data(),wrap=document.createElement("div");wrap.className="entry";
    const title=document.createElement("b");title.textContent=t.name+" ("+t.mode+") ";
    const count=document.createElement("button");count.className="btn secondary";count.textContent="View registrations";
    count.onclick=async()=>{const regs=await getDocs(collection(db,"tournaments",s.id,"registrations"));const names=regs.docs.map(r=>r.data().displayName||r.id);alert(`${t.name}\nRegistered: ${regs.size}\n${names.join("\n")||"No players yet"}`);};
    const close=document.createElement("button");close.className="btn secondary";close.textContent=t.status==="open"?"Close":"Reopen";
    close.onclick=async()=>{const {updateDoc}=await import("https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js");await updateDoc(doc(db,"tournaments",s.id),{status:t.status==="open"?"closed":"open"});await loadTournaments();await loadAdminTournaments();};
    wrap.append(title,count,close);host.append(wrap);
  }
}
