plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "eagle.com"
    compileSdk = 35
    defaultConfig { applicationId = "eagle.com"; minSdk = 23; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}
