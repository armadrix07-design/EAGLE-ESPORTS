# EAGLE ESPORTS — Firebase starter

এই প্রজেক্টটি EAGLE ESPORTS-এর deployable web starter এবং Android Studio WebView wrapper: Google login, phone OTP login, public tournament listing, signed-in player free registration, এবং একটি নির্দিষ্ট Firebase Auth UID-র জন্য admin UI।

## 1) Firebase project তৈরি
1. https://console.firebase.google.com/ খুলে Add project চাপো।
2. Project তৈরি হলে Web app (</>) যোগ করো; Firebase config কপি করো।
3. Authentication → Sign-in method-এ Google এবং Phone enable করো।
4. Authentication → Settings → Authorized domains-এ তোমার deploy করা domain যোগ করো। Local test-এর জন্য localhost থাকতে পারে।
5. Firestore Database তৈরি করো (production mode বেছে নাও)।

## 2) Config বসাও
`public/app.js` খুলে `firebaseConfig`-এর YOUR_... মানগুলো তোমার Firebase Web app config দিয়ে বদলাও। Secret service-account key কখনো browser code-এ দেবে না।

## 3) নিজের Admin UID সেট করো
1. প্রথমে ওয়েবসাইট চালু করে নিজের Google account বা phone number দিয়ে একবার sign in করো।
2. Firebase Console → Authentication → Users-এ নিজের user খুলে UID কপি করো।
3. `public/app.js`-এর `ADMIN_UID`-তে UID বসাও।
4. `firestore.rules`-এর `PASTE_YOUR_ADMIN_AUTH_UID_HERE`-এর জায়গায় একই UID বসাও।
5. নিচের rules Firestore → Rules-এ publish করো।

**গুরুত্বপূর্ণ:** শুধু app.js-এ Admin UID বসালেই নিরাপত্তা হয় না। Firestore Rules-এও একই UID থাকতে হবে। Admin UID কাউকে দেবে না। আরও শক্তিশালী production admin ব্যবস্থা (custom claims + trusted server) পরে যোগ করা উচিত।

## 4) Hosting
দ্রুত পরীক্ষা: Firebase Console → Hosting → Get started অনুসরণ করো; Firebase CLI-ও ব্যবহার করা যায়।
এই ফোল্ডারের `public` directory-ই hosting root। `firebase.json` দেওয়া আছে।
CLI থাকলে:
```bash
npm install -g firebase-tools
firebase login
firebase init hosting
# public directory: public
# single-page app: No
firebase deploy
```
Firestore rules deploy:
```bash
firebase deploy --only firestore:rules
```

## 5) Android APK
এই একই responsive web app Android WebView wrapper বা Trusted Web Activity দিয়ে APK করা যায়। আগে Hosting-এ HTTPS website deploy করো, তারপর Android Studio-তে wrapper বানাও। Phone OTP auth-এর জন্য production Android app-এ Firebase Android SDK এবং app verification (Play Integrity/reCAPTCHA fallback) সঠিকভাবে configure করতে হবে। শুধু HTML ফাইল APK নয়।

## Data model
- `users/{uid}`: basic profile
- `tournaments/{tournamentId}`: name, mode, map, startAt, deadlineAt, maxPlayers, rules, status
- `tournaments/{tournamentId}/registrations/{uid}`: one registration per Firebase UID

## Current limitations — before public launch
- Free registration only; no payments.
- Room ID/password distribution is intentionally not implemented. Admin should publish room details only to confirmed participants via a trusted backend, not public tournament documents.
- Player UID field, team member roster, capacity enforcement, waitlist, cancellation, notifications, result verification and anti-cheat/admin audit logs are not yet implemented.
- Capacity enforcement must be implemented transactionally with a server-side counter/Cloud Function before accepting real players; the current starter enforces one registration per UID but does not guarantee max player capacity under simultaneous joins.
- Phone auth can incur SMS charges and is subject to Firebase quotas and regional availability.
- Never collect game passwords. Do not request or store a player's Free Fire account password.
- Use only tournaments you are authorized to organize; this is not affiliated with Garena.


## 6) Android APK wrapper
`android/` ফোল্ডারটি Android Studio-তে Open করো। `android/app/src/main/java/com/eagle/esports/MainActivity.kt`-এ `https://YOUR_HOSTING_DOMAIN`-এর জায়গায় Firebase Hosting deploy করা HTTPS URL বসাও। তারপর Android Studio → Build → Build Bundle(s) / APK(s) → Build APK(s)।

**গুরুত্বপূর্ণ:** এই ZIP-এ তৈরি APK নেই। APK build করতে Android Studio/Android SDK, Firebase Web config, Admin UID এবং deploy করা HTTPS Hosting URL প্রয়োজন। Google/Phone login-এর জন্য Hosting domain Firebase Authentication-এর Authorized domains-এ যোগ করতে হবে। Android WebView-তে Google popup login সীমাবদ্ধ হতে পারে; production-এর জন্য native Firebase Android Authentication SDK ব্যবহার করে sign-in flow করা উচিত।


## EAGLE ESPORTS Android wrapper status
- Android applicationId is set to `eagle.com` to match the supplied Firebase Android registration.
- `android/app/google-services.json` is included. This current WebView wrapper does not yet use the native Google Services Gradle plugin; the JSON is retained for the matching Android registration.
- Before building/installing, deploy the `public` web app to Firebase Hosting and replace `https://YOUR_HOSTING_DOMAIN` in `android/app/src/main/java/com/eagle/esports/MainActivity.kt` with the actual HTTPS Hosting URL.
- The APK has not been compiled or signed by this ZIP preparation.
